import requests
from bs4 import BeautifulSoup

# id = 2247508513
# id_list = []
# print("pt" in "httpjpsajdpasjdsipdjsapidjsadpiddjsajdippt")
#
# print(id_list)

list1 = [114,514]
import random

print(random.randint(1, 2))
list2 = [1919,810]
print(list1[1:2])
for i in list1:
    print(i)
    for j in list2:
        print(j)


